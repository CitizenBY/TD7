<?php
include_once(__DIR__."/./utils/userutils.php");
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="main.css" />
    <script src="main.js"></script>
</head>
<body>
<?php

if(isset($_GET['username'])){
    $username=$_GET['username'];
    getInfosFromUsers($username);
  }
if(isset($_GET['username'])){
    $username=$_GET['username'];
    getArticlesFromUser($username);
  }

  
?>
</body>
</html>