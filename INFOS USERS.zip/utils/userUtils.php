<?php
session_start();
include_once(__DIR__."/./dbUtils.php");

function getArticlesFromUser(){
  $mysql = connect();

$query = "SELECT title, content, date FROM article 
WHERE user_id=$username";

$req = $mysql->prepare($query);
execute($req);

$articles=array();

while($row = $req->fetch()){
  $title = $row['title'];
  $content = $row['content'];
  $date = $row['date'];

  $article = array(
    "title" => $title,
    "content" => $content,
    "date" => $date
  );

  array_push($articles,$article);
}

return $id;
}


function getInfosFromUser(){
  $mysql = connect();

$query = "SELECT username,firstname,lastname,email,phone,gender FROM user 
WHERE username=$username";

$req = $mysql->prepare($query);
execute($req);

$users=array();

while($row = $req->fetch()){
  $username = $row['username'];
  $firstname = $row['firstname'];
  $lastname = $row['lastname'];
  $email = $row['email'];
  $phone = $row['phone'];
  $gender = $row['gendrer'];

  $user = array(
    "username" => $username,
    "firstname" => $firstname,
    "lastname" => $lastname,
    "email" => $email,
    "phone" => $phone,
    "gender" => $gender
  );

  array_push($users,$user);
}

return $id;
}
